<?php
include 'koneksi.php';
$id_fasilitas = $_POST['id_fasilitas'];
$nama_fasilitas = $_POST['nama_fasilitas'];
$deskripsi= $_POST['deskripsi'];

mysqli_query($koneksi, "INSERT INTO tbl_fasilitas VALUES('','$nama_fasilitas','$deskripsi')");

header("location: admfacility.php");
?>