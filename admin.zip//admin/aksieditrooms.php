<?php
include 'koneksi.php';

$id_kamar = $_POST['id_kamar'];
$tipe_kamar = $_POST['tipe_kamar'];
$jumlah_kamar = $_POST['jumlah_kamar'];
$harga_kamar = $_POST['harga_kamar'];
$fasilitas = $_POST['fasilitas'];

mysqli_query($koneksi, "UPDATE tbl_tipe_kamar SET id_kamar='$id_kamar', tipe_kamar ='$tipe_kamar', 
jumlah_kamar='$jumlah_kamar', harga_kamar='$harga_kamar', fasilitas='$fasilitas' WHERE id_kamar='$id_kamar'");

header("location: admrooms.php");
?>