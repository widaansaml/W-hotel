<?php
include 'koneksi.php';
$id_kamar=$_POST['id_kamar'];
$tipe_kamar = $_POST['tipe_kamar'];
$jumlah_kamar = $_POST['jumlah_kamar'];
$harga_kamar = $_POST['harga_kamar'];
$fasilitas = $_POST['fasilitas'];

mysqli_query($koneksi, "INSERT INTO tbl_tipe_kamar (id_kamar,tipe_kamar,jumlah_kamar,harga_kamar,fasilitas) VALUES('','$tipe_kamar','$jumlah_kamar','$harga_kamar','$fasilitas')");
	header("location:admrooms.php");
?>