<?php
include 'koneksi.php';

$id_fasilitas = $_POST['id_fasilitas'];
$nama_fasilitas = $_POST['nama_fasilitas'];
$deskripsi = $_POST['deskripsi'];

mysqli_query($koneksi, "UPDATE tbl_fasilitas SET id_fasilitas='$id_fasilitas', nama_fasilitas ='$nama_fasilitas',deskripsi='$deskripsi' WHERE id_fasilitas='$id_fasilitas'");

header("location: admfacility.php");
?>