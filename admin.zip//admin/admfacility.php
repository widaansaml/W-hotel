<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->


<head>
	<meta charset="utf-8">
	<title>w hotel</title>
	<meta name="description" content="">
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- <link rel="shortcut icon" href="img/favicon.png"> -->

	<link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet'>

	<!-- Syntax Highlighter -->
	<link rel="stylesheet" type="text/css" href="syntax-highlighter/styles/shCore.css" Mariana="all">
	<link rel="stylesheet" type="text/css" href="syntax-highlighter/styles/shThemeDefault.css" Mariana="all">

	<!-- Font Awesome CSS-->
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<!-- Normalize/Reset CSS-->
	<link rel="stylesheet" href="assets/css/normalize.min.css">
	<!-- Main CSS-->
	<link rel="stylesheet" href="assets/css/main.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">

</head>

<body id="welcome">

	<aside class="left-sidebar">
		<div class="logo">
			<a href="#">
				<h1>Admin </h1>
			</a>
		</div>
		<nav class="left-nav">
		
			<ul id="nav">
			<li class="current"><a href="admrooms.php">Data Kamar</a></li>
				<li class="current" ><a href="admfacility.php">Data Fasilitas Hotel</a></li>
				<li class="current" ><a href="logout.php">Logout</a></li>
</ul>
			
		</nav>
	</aside>
		<div id="main-wrapper">
		<div class="main-content">
			<section id="welcome">
				<div class="content-header">
					<h1>Data Fasiltas</h1>
				</div>
				<br>
			
				<header>
		<h3 align="center"> Tambah data fasilitas </h3>
		<br>
		</header>

		<form action = "aksitambahfasility.php" method="POST" align="center">
			<fieldset>
			<p>
			<label for "nama_fasilitas" > Nama Fasilitas </label>
			<input type="text" name="nama_fasilitas" required>
</p>
			<p><label for "deskripsi"> Keterangan </label>
			<input type="text" name="deskripsi" required>
</p>
<p>
	<input type="submit" value="tambah" align="center">
</p>
</fieldset>
		</form>

	</br>

</table>


				<div class="welcome">
					<table class="table1" align="center">
			<tr>
			<th>No</th>
			<th>Nama Fasilitas</th>
			<th>Keterangan</th>
			<th>Aksi</th>
		
		</tr>
		<tr>
		<?php
                  include 'koneksi.php';
                  $data = mysqli_query($koneksi, "SELECT * FROM tbl_fasilitas");
                  while($d = mysqli_fetch_array($data)){
                    ?>
                  <tr>
                      <td><?php echo $d['id_fasilitas']; ?></td>
                      <td><?php echo $d['nama_fasilitas']; ?></td>
                      <td><?php echo $d['deskripsi']; ?></td>
					  
                      <td><a href="editdatafasility.php?id_fasilitas=<?php echo $d['id_fasilitas'];?>"> Edit</a>
                      <a class="d-block" href="deletefasility.php?id_fasilitas=<?php echo $d['id_fasilitas'];?>" onclick="return confirm('Delete This Data?')"> Delete</a>
                    </td>
                  <?php 
                  }
                  ?>
				  </tr>

	</table>	

			</section>
		</div>
	
    
</body>
</html>