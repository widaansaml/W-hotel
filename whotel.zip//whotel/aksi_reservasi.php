<?php
include 'koneksi.php';

$kd_reservasi =$_POST['kd_reservasi'];
$id_tamu =$_POST['id_tamu'];
$tgl_check_in =$_POST['tgl_check_in'];
$tgl_check_out =$_POST['tgl_check_out'];
$jml_kamar =$_POST['jml_kamar'];
$jml_orang =$_POST['jml_orang'];
$jml_hari =$_POST['jml_hari'];
$id_kamar =$_POST['id_kamar'];
$tgl_dipesan =$_POST['tgl_dipesan'];
$total_bayar =$_POST['total_bayar'];
$status_reservasi=$_POST['status_reservasi'];



	$data_rsvp = mysqli_query ($koneksi,"INSERT INTO tbl_reservasi (kd_reservasi, id_tamu, tgl_check_in,tgl_check_out,jml_kamar,jml_orang,jml_hari,id_kamar,tgl_dipesan,total_bayar, status_reservasi)
	 VALUES ('','$id_tamu','$tgl_check_in','$tgl_check_out','$jml_kamar','$jml_orang','$jml_hari','$id_kamar','$tgl_dipesan','$total_bayar','')");

	
if($data_rsvp){
	//$_POST['kd_reservasi']=$kd_reservasi;
	$_SESSION['email'] =$email;
	$_SESSION['status_reservasi'] ="login";
	header("location:detail_reservasi.php?kd_reservasi=$kd_reservasi");
}else{
	header("location:reservasii.php?pesan=gagal");
}
?>