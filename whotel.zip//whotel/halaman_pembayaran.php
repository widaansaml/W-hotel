<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Checkout example · Bootstrap v5.1</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/checkout/">

    

    <!-- Bootstrap core CSS -->
<link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="../assets/js/form-validation.css" rel="stylesheet">
  </head>
  <body class="bg-light">
     <!-- cek apakah sudah login -->
	<?php 
	session_start();
    
	if($_SESSION['status']!="login"){
		header("location:index.php?pesan=belum_login");
 
	}
?>
  <?php
  include "../config.php";
 
$email = $_SESSION['email'];
$kd_reservasi = $_GET['kd'];
$data = mysqli_query($koneksi,"select * from tbl_reservasi JOIN tbl_tamu ON tbl_reservasi.kd_tamu=tbl_tamu.kd_tamu
                     JOIN tbl_tipe_kamar ON tbl_reservasi.id_kamar=tbl_tipe_kamar.id_kamar where kd_reservasi='$kd_reservasi'");
	$row = mysqli_fetch_array($data);


    	// mengambil data tamu dengan kode paling besar
	$query = mysqli_query($koneksi, "SELECT max(kd_bayar) as kd_bayar FROM tbl_pembayaran");
	$data_bayar = mysqli_fetch_array($query);
	$kd_bayar = $data_bayar['kd_bayar'];
 
	$urutan = (int) substr($kd_bayar, 3, 3);
 
	// bilangan yang diambil ini ditambah 1 untuk menentukan nomor urut berikutnya
	$urutan++;
 
	// membentuk kode barang baru
	// perintah sprintf("%03s", $urutan); berguna untuk membuat string menjadi 3 karakter
	// misalnya perintah sprintf("%03s", 15); maka akan menghasilkan '015'
	// angka yang diambil tadi digabungkan dengan kode huruf yang kita inginkan, misalnya BRG 
	$huruf = "BYR";
	$kd_bayar = $huruf . sprintf("%03s", $urutan);
?>
<div class="container">
  <main>
  
    <?php if ($row['status_reservasi']==0) {
      ?>

    <div class="py-5 text-center">
      <img class="d-block mx-auto mb-4" src="../assets/img/logo_login.jpg" alt="" width="72" height="57">
      <h2>Pembayaran</h2>
      <p class="lead">Silahkan isi dan upload bukti transfer pembayaran anda di bawah ini.</p>
    </div>
    <form method="POST" action="aksi_bayar.php" class="form-control" enctype="multipart/form-data">
    <h4 class="mb-3">Pembayaran</h4>
          <hr class="my-4">
          
          <div class="row gy-3">
            <div class="col-md-6">
              <label for="cc-name" class="form-label">Kode Reservasi</label>
              <input type="text" class="form-control" id="cc-name" name="kd_reservasi" value="<?= $row['kd_reservasi'];?>" readonly>
              <input type="hidden" class="form-control"  name="tgl_bayar" value="<?php echo date("Y-m-d"); ?>">
              <input type="hidden" class="form-control"  name="kd_bayar" value="<?php echo $kd_bayar;?>">
            </div>
            <div class="col-md-6">
              <label for="cc-name" class="form-label">Nama Pemesan</label>
              <input type="text" class="form-control" id="cc-name" value="<?= $row['nama_tamu'];?>" readonly>
            </div>
            <div class="col-md-6">
              <label for="cc-number" class="form-label">Nama Akun Rekening Pengirim</label>
              <input type="text" class="form-control" id="cc-number" name="nama_akun_rekening"  placeholder="" required>
              <div class="invalid-feedback">
                Credit card number is required
              </div>
            </div>

            <div class="col-md-3">
              <label for="cc-expiration" class="form-label">Nomor Rekening Pengirim</label>
              <input type="text" class="form-control" id="cc-expiration" name="nmr_rekening" placeholder="" required>
              <div class="invalid-feedback">
                Expiration date required
              </div>
            </div>

            <div class="col-md-3">
              <label for="cc-cvv" class="form-label">Upload Bukti Transfer</label>
              <input type="file" class="form-control" id="cc-cvv" name="bukti_bayar" placeholder="" required>
              <div class="invalid-feedback">
                Security code required
              </div>
            </div>
          </div>

          <hr class="my-4">

          <button class="w-100 btn btn-primary btn-lg" type="submit">Bayar</button>
        </form>
      </div>
    </div>
  <?php  } 
  else {
    echo "<h2> Anda sudah melakukan pembayaran, silahkan melakukan check in sesuai dengan waktu yang telah ditentukan.</h2>";
  }
  
  ?>
  </main>

  <footer class="my-5 pt-5 text-muted text-center text-small">
    <p class="mb-1">&copy; 2017–2021 Company Name</p>
    <ul class="list-inline">
      <li class="list-inline-item"><a href="#">Privacy</a></li>
      <li class="list-inline-item"><a href="#">Terms</a></li>
      <li class="list-inline-item"><a href="#">Support</a></li>
    </ul>
  </footer>
</div>


    <script src="../assets/js/bootstrap.bundle.min.js"></script>

      <script src="../assets/js/form-validation.js"></script>
  </body>
</html>
