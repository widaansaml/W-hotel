<?php

include 'koneksi.php';

$id_tamu=$_POST['id_tamu'];
$nama_pengguna =$_POST['nama_pengguna'];
$no_telepon=$_POST['no_telepon'];
$alamat=$_POST['alamat'];
$kecamatan=$_POST['kecamatan'];
$kabupaten=$_POST['kabupaten'];
$provinsi=$_POST['provinsi'];
$email=$_POST['email'];
$kata_sandi=md5($_POST['kata_sandi']);




$data_tamu=mysqli_query($koneksi,"INSERT INTO tbl_tamu VALUES('$id_tamu','$nama_pengguna','$no_telepon','$alamat','$kecamatan','$kabupaten','$provinsi','$email','$kata_sandi')");
if($data_tamu){
	header("location:masuk.php");
	}else{
	header("location:index.php?pesan=gagal");
}
?>