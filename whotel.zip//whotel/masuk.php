<!doctype html>
<html >
<head>
	<title>W HOTEL</title>
	<link rel="stylesheet" type="text/css" href="style.css">
<style type="">
	body{
	font-family: sans-serif;
	background: #d5f0f3;
}


.tulisan_login{
	text-align: center;
	
	text-transform: uppercase;
}

.kotak_login{
	width: 350px;
	background: white;
	
	margin: 80px auto;
	padding: 30px 20px;
}

label{
	font-size: 11pt;
}

.form_login{
	
	box-sizing : border-box;
	width: 100%;
	padding: 10px;
	font-size: 11pt;
	margin-bottom: 20px;
}

.tombol_login{
	background: skyblue;
	color: white;
	font-size: 11pt;
	width: 100%;
	border: none;
	border-radius: 3px;
	padding: 10px 20px;
}


</style></head>



<body>
	<?php
    if(isset($_GET ['pesan'])){
        if($_GET['pesan']== "gagal"){
            echo"login gagal! username dan password salah!";

        }else if ($_GET['pesan']=="logout"){
            echo "anda telah berhasil logout";
             }else if ($_GET['pesan']=="belum_login"){
                echo"anda harus login untuk mengakses halaman admin";
            }
    }
    ?>
	<div class="kotak_login">
		<p class="tulisan_login">Please Login</p>
	<form method="POST" action="aksi_login.php">
			<label>Email</label>
			<input type="email" name="email" class="form_login" placeholder="email .." required>
 
			<label>Password</label>
			<input type="password" name="kata_sandi" class="form_login" placeholder="Password .." required>
 
			<input type="submit" class="tombol_login" value="LOGIN">
 
			<br/>
			<br/>
			<center>
				<a href="pendaftarann.php">SIGN-IN</a>
			</center>
		</form>
		
	</div>
 
 
</body>
</html>