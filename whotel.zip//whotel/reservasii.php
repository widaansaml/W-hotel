<!DOCTYPE html>
<html lang="en">
  <head>
    <title>W HOTEL</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  
 <body class="bg-light">
     <!-- cek apakah sudah login -->
  <?php 
  session_start();
    
  if($_SESSION['status']!="login"){
    header("location:index.php?pesan=belum_login");
 
  }
?>
<?php
  include 'koneksi.php';
 
$email = $_SESSION['email'];
$id_kamar= $_GET['id_kamar'];
// echo "$id_kamar"; die();
//mengambil data kamar
$data_kamar = mysqli_query($koneksi,"SELECT* FROM tbl_tipe_kamar WHERE id_kamar='$id_kamar'");
  $kamar = mysqli_fetch_array($data_kamar);
  
  // echo "$k";

$data = mysqli_query($koneksi,"SELECT * FROM tbl_tamu WHERE email='$email'");
  $row = mysqli_fetch_array($data);

  //$query = mysqli_query($koneksi,"SELECT * FROM tbl_reservasi JOIN tbl_tamu ON tbl_reservasi.id_tamu=tbl_tamu.id_tamu JOIN tbl_tipe_kamar ON tbl_reservasi.id_kamar=tbl_tipe_kamar.id_kamar WHERE email='$email'");
  //$reservasi = mysqli_fetch_array($query);

  // mengambil data tamu dengan kode paling besar
  $query = mysqli_query($koneksi, "SELECT max(kd_reservasi) as kd_reservasi FROM tbl_reservasi");
  $data = mysqli_fetch_array($query);
  $kd_reservasi = $data['kd_reservasi'];
 
  $urutan = (int) substr($kd_reservasi, 3, 3);
 
  // bilangan yang diambil ini ditambah 1 untuk menentukan nomor urut berikutnya
  $urutan++;
 
  // membentuk kode barang baru
  // perintah sprintf("%03s", $urutan); berguna untuk membuat string menjadi 3 karakter
  // misalnya perintah sprintf("%03s", 15); maka akan menghasilkan '015'
  // angka yang diambil tadi digabungkan dengan kode huruf yang kita inginkan, misalnya BRG 
  $huruf = "RSV";
  $kd_reservasi = $huruf . sprintf("%03s", $urutan);
  ?>
   
 
    
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="tampilan_tamu.php">W HOTEL</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="tampilan_tamu.php" class="nav-link">Home</a></li>
	          <li class="nav-item active"><a href="rooms.php" class="nav-link">Rooms</a></li>
	          <li class="nav-item"><a href="fasilitas.php" class="nav-link">Facility</a></li>
	          <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
            <li class="nav-item"><a href="logout.php" class="nav-link">Log-out</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
		<div class="hero-wrap" style="background-image: url('images/bg_3.jpg');">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text d-flex align-itemd-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center d-flex align-items-end justify-content-center">
          	<div class="text">
	            <p class="breadcrumbs mb-2"><span class="mr-2"><a href="tampilan_tamu.php">Home</a></span> <span>Reservation</span></p>
	            <h1 class="mb-4 bread">FORM RESERVATION</h1>
            </div>
          </div>
        </div>
      </div>
    </div>


          <div class="col-lg-4 sidebar ftco-animate " >

          <form method="POST" action="aksi_reservasi.php" class="needs-validation" novalidate>

           <center><table border="0" cellpadding="10px" style=""> 
    <h1 align="center">RESERVATION</h1>
    
          <div class="row">
            <div class="col-md-12 form-group ">
              <label for="firstName" class="form-label">Nama Lengkap</label>
              <input type="text" class="form-control" id="firstName" placeholder="" value="<?php echo $row['nama_pengguna'];?>" name="nama_tamu" readonly>

              <input type="hidden" class="form-control"  name="kd_reservasi" value="<?php echo $kd_reservasi;?>">
              <input type="hidden" class="form-control"  name="id_tamu" value="<?php echo $row['id_tamu'];?>">
              <input type="hidden" class="form-control"  name="tgl_dipesan" value="<?php echo date("Y-m-d"); ?>">
              <input type="hidden" class="form-control"  name="id_kamar" value="<?php echo $kamar['id_kamar'];?>">
               <div class="col-md-12 form-group">
                  <label class="text-black font-weight-bold" for="name">Phone</label>
                  <input type="text" name="no_telepon" class="form-control " value="<?php echo $row['no_telepon'];?>"readonly>
                </div>
            </div>

            <div class="col-md-12 form-group">
              <span><label for="email" >Jenis Kamar </label></span>
              <input type="text" class="form-control" placeholder="tipe kamar" name="tipe_kamar" value="<?php echo $kamar['tipe_kamar'];?>" readonly>
              <!-- <div class="invalid-feedback">
                Please enter a valid email address for shipping updates.
              </div> -->
            </div>
              <div class="col-md-12 form-group">
              <label for="username" class="text-black font-weight-bold">Harga Kamar</label>
              <div class="input-group has-validation">
              <input type="text" class="form-control" id="harga_kamar" name="harga_kamar" onkeyup="total()" value="<?php echo $kamar['harga_kamar'];?>" readonly>
              </div>
            </div>

           
            

            <div class="col-sm-12">
              <label for="lastName" class="form-label">Jumlah Kamar yang Dipesan</label>
              <input type="number" class="form-control" id="lastName" placeholder="jumlah kamar" name="jml_kamar" onkeyup="total()"  min=1 max="<?php echo $kamar['jml_kamar'];?>"required>
              <div class="invalid-feedback">
                Isi jumlah kamar yang ingin dipesan.
              </div>
            </div>

            <div class="col-sm-12">
              <label for="lastName" class="form-label">Jumlah Orang</label>
              <input type="number" name="jml_orang" class="form-control" id="lastName" placeholder="jumlah orang" name="jml_orang" min=1 max="<?php echo $kamar['jml_orang'];?>" required>
              <div class="invalid-feedback">
                Isi jumlah orang yang akan menginap.
              </div>
            </div>
      
            <div class="col-md-12">
              <label for="country" class="form-label">Check In</label>
              <input type="date" class="form-control" id="country" name="tgl_check_in" min="<?php echo date("Y-m-d"); ?>" required>
              <div class="invalid-feedback">
                Please select a valid country.
              </div>
            </div>

            <div class="col-md-12">
              <label for="country" class="form-label">Check Out</label>
              <input type="date" class="form-control" id="country" name="tgl_check_out" min="<?php echo date("Y-m-d"); ?>" required>
              <div class="invalid-feedback">
                Please select a valid country.
              </div>
            </div>
 <div class="col-md-12 form-group">
             <td></td> <label for="username" class="text-black font-weight-bold">Lama Menginap</label>
              <div class="input-group has-validation">
                <input type="text" class="form-control" id="jml_hari" name="jml_hari" onkeyup="total()" min=1 required>
              </div>
            </div>
            <div class="col-md-12 form-group">
              <td></td>
                  <label class="text-black font-weight-bold" for="zip">Total Cost</label>
                  <input type="number" class="form-control"  id="total_bayar" name="total_bayar" value="<?php echo $kamar['total_bayar'];?>">
                </div>
            <div class="col-md-12">
    
              <td></td>
              <td></td>
            
            
              <td><input type="submit" value="BOOKING"></td></tr>
                  </table></p>
            </div>  
          </div>
        </div>
      </div>
    </section> <!-- .section -->

    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">W HOTEL</h2>
              <p>W HOTEL is specially designed to offer ultimate comfort and provide guests with a relaxing sanctuary from the outside world.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Useful Links</h2>
              <ul class="list-unstyled">
                
                <li><a href="rooms.php" class="py-2 d-block">Rooms</a></li>
                <li><a href="fasilitas.php" class="py-2 d-block">Facility</a></li>
               
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Privacy</h2>
              <ul class="list-unstyled">
                
                <li><a href="about.php" class="py-2 d-block">About </a></li>
                <li><a href="contact.php" class="py-2 d-block">Contact Us</a></li>
               
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Have a Questions?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">Jl. Mahendradatta No.93,Padangsambian,Kec.Denpasar Bar.,Denpasar City,Bali</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+2 392 3929 210</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">info@yourdomain.com</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/jquery.mb.YTPlayer.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <!-- // <script src="js/jquery.timepicker.min.js"></script> -->
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
  <script>
    function total_bayar() {
      var txtFirstNumberValue=document.getElementById('harga_kamar').value;
      var txtSecondNumberValue=document.getElementById('jml_hari').value;
      var txtThirdNumberValue=document.getElementById('jml_kamar').value;
      var result = parseInt(txtFirstNumberValue) * parseInt(txtSecondNumberValue) * parseInt(txtThirdNumberValue);
      if(!isNaN(result)){
        document.getElementById('total_bayar').value=result;
      }
      
    }
    
  </script>
</html>