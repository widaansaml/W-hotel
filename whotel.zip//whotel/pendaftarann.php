<!doctype html>
<html lang="en">
<head>
	<title>W HOTEL</title>
<style >	
	body {
background-color: #d5f0f3;
;
background-size: cover;
background-position: center;
background-repeat: no repeat;
}



table{
	margin-left:auto;
	margin-right: auto;
	box-shadow: 5px 10px 20px rgba(0,0,0,0.7);
position: center;
border-radius:10px;
width: 500px;
height: 400px;
margin: 40px auto 200px auto;
padding: 10px;
	background-color:white;
}
h1{
	text-align:center;
}
input[type=submit]{
	background-color: white;
}
div{
border-radius: 10px; 
backgroud-color: #f2f2f2;
padding : 5px; 
}

</style>
</head>
 <?php

	// menghubungkan dengan koneksi database
	include 'koneksi.php';
 
	// mengambil data tamu dengan kode paling besar
	$query = mysqli_query($koneksi, "SELECT max(id_tamu) as id_tamu FROM tbl_tamu");
	$data = mysqli_fetch_array($query);
	$id_tamu= $data['id_tamu'];
 
	// mengambil angka dari kode barang terbesar, menggunakan fungsi substr
	// dan diubah ke integer dengan (int)
	$urutan = (int) substr($id_tamu, 3, 3);
 
	// bilangan yang diambil ini ditambah 1 untuk menentukan nomor urut berikutnya
	$urutan++;
 
	// membentuk kode barang baru
	// perintah sprintf("%03s", $urutan); berguna untuk membuat string menjadi 3 karakter
	// misalnya perintah sprintf("%03s", 15); maka akan menghasilkan '015'
	// angka yang diambil tadi digabungkan dengan kode huruf yang kita inginkan, misalnya BRG 
	$huruf = "TM";
	$id_tamu = $huruf . sprintf("%03s", $urutan);
	?>
<body>
	 <?php 
if(isset($_GET['pesan'])){
	if($_GET['pesan'] == "gagal"){
		echo "Data tidak tersimpan dan tidak terdaftar";
	}
}
?>
    <div class="kotak">
    	<form method="post" action="aksidaftar.php" >
	<table> 
		<h1>SIGN-UP</h1>
		<tr>
			<td><input type="hidden" name="id_tamu" required="required" value="<?php echo $id_tamu ?>" readonly></td>
		</tr>
		<tr>
		 <td>Name</td> 
		 <td>:</td> 
		 <td><input type="text" name="nama_pengguna" required></td> 
		</tr> 
		<tr> 
			    	   	<td>No Hp</td> 
			    	   	<td>:</td> 
			    	   	<td><input type="text" name="no_telepon" required></td>
			    	   	 </tr> 
			    <tr> 
			    	<td>Adress</td> 
			    	<td>:</td> 
			    	<td><textarea cols="22" rows="3" name="alamat" required></textarea></td>
			    	 </tr> 
			    	 <tr>
			    	   	 	<td>Districts</td> 
			    	   	 	<td>:</td> 
			    	   	 	<td><input type="text" name="kecamatan" required>
			    	   	 
			    	   	 	  </tr>
			    	   	 	   <tr>
			    	   	 	<td>City</td> 
			    	   	 	<td>:</td> 
			    	   	 	<td><input type="text" name="kabupaten"required>
			    	   	 	   </tr> 
			    	   	 	    
			    	   	 	   <tr>
			    	   	 	<td>Province</td> 
			    	   	 	<td>:</td> 
			    	   	 	<td><input type="text" name="provinsi"required>
			    			 </tr> 
			    	   	 	   

			    	
			    	  <td>E-mail</td>
			    	   <td>:</td> 
			    	  <td> <input type="email" name="email" required></td> 
			    	</tr>
			    	   
			    	   	  
			    	   	 	 <tr>
			    	  <td>Password</td>
			    	   <td>:</td> 
			    	  <td><input type="password" name="kata_sandi" required></td> 
			    	</tr>
			    	<tr>
			    		  	 	 <tr>
			    	  <td>Comfirm password</td>
			    	   <td>:</td> 
			    	  <td><input type="password" required></td> 
			    	</tr>
			    	<tr>
			    		<td></td>
			    		<td></td>
			    	
			    	
			    		<td><a href="masuk.php"><input type="submit"  value="SIGN-UP"/> </td></tr>
			    	   	 	</table>
			    	   	 	</body>
			    	   	 	   </html>