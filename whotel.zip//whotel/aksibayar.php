<?php
//menghubungkan dengan koneksi databse
include'koneksi.php';

//menangkap data yang dikirim dari form
$kd_bayar=$_POST['kd_bayar'];
$kd_reservasi=$_POST['kd_reservasi'];
$tgl_bayar=$_POST['tgl_bayar'];
$nama_akun_rekening=$_POST['nama_akun_rekening'];
$no_rek=$_POST['no_rek'];
$name=$_FILES['bukti_bayar']['name'];
$file=$_FILES['bukti_bayar']['tmp_name'];
$status=$_POST['status'];

//menyimpan data reservasi ke database
move_uploaded_file($file,"../bukti/$name");
$data_bayar = 
mysqli_query($koneksi,"INSERT INTO tbl_pembayaran VALUES ('$kd_bayar','$kd_reservasi', '$tgl_bayar', '$nama_akun_rekening', '$no_rek','','', '1')");

if($data_bayar){
	//$_POST['kd_reservasi']=$kd_reservasi;
	$_SESSION['email']=$email;
	$_SESSION['status']="login";
	header("location:cetak.php?kd=$kd_bayar");
}else{
	header("location:index.php?pesan=gagal");
}
?>