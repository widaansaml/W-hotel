<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>DETAIL RESERVASI</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/checkout/">

    

    <!-- Bootstrap core CSS -->
<link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="../assets/css/form-validation.css" rel="stylesheet">
  </head>
  <body class="bg-light">
       <!-- cek apakah sudah login -->
	<?php 
	session_start();
    
	if($_SESSION['status']!="login"){
		header("location:index.php?pesan=belum_login");
 
	}
?>
  <?php
  include "koneksi.php";
 
$email = $_SESSION['email'];
$kd_reservasi = $_GET['kd_reservasi'];
$data = mysqli_query($koneksi,"select * from tbl_reservasi JOIN tbl_tamu ON tbl_reservasi.id_tamu=tbl_tamu.id_tamu
                     JOIN tbl_tipe_kamar ON tbl_reservasi.id_kamar=tbl_tipe_kamar.id_kamar where kd_reservasi='$kd_reservasi'");
	$row = mysqli_fetch_array($data);
// echo "$kd_reservasi"; die();
?>
<div class="container">
  <main>
    <div class="py-5 text-center">

      <h2>DETAIL RESERVASI ANDA</h2>
      <p class="lead"></p>
    </div>

    <div class="row g-5">
      <div class="col-md-5 col-lg-4 order-md-last">
        <h4 class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-primary">Lakukan pembayaran via transfer bank</span>
        </h4>
        <ul class="list-group mb-3">
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">BCA</h6>
              <small class="text-muted">0202022921093404</small>
            </div>
           
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Mandiri</h6>
              <small class="text-muted">839483974389743890</small>
            </div>
            
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Batas Waktu Pembayaran</h6>
              <small class="text-muted">839483974389743890</small>
            </div>
            
          </li>
        </ul>

      
      </div>
      <div class="col-md-7 col-lg-8">
       
      <h4 class="mb-3">Nomor Reservasi   : #<?php echo $row['kd_reservasi'];?></h4>
      <h5 class="mb-3">Tanggal Reservasi : <?php echo $row['tgl_dipesan'];?></h5>
          <hr class="my-4">
              <label class="form-check-label" for="credit">Nama Pemesan    :</label> <?php echo $row['id_tamu'];?><br>
              <label class="form-check-label" for="credit">Email           :</label> <?php echo $row['email'];?><br>
              <label class="form-check-label" for="credit">Waktu Check In: </label> <?php echo $row['tgl_check_in'];?> / Pukul: 13.00 WIB<br>
              <label class="form-check-label" for="credit">Waktu Check Out: </label><?php echo $row['tgl_check_out'];?> / Pukul: 12.00 WIB<br>
              <label class="form-check-label" for="credit">Terhitung </label><?php echo $row['jml_hari'];?> malam<br>
              <label class="form-check-label" for="credit">Tipe Kamar  : </label><?php echo $row['tipe_kamar'];?><br>
              <label class="form-check-label" for="credit">Fasilitas Kamar:</label> <?php echo $row['fasilitas'];?><br>
              <label class="form-check-label" for="credit">Jumlah Kamar:</label> <?php echo $row['jml_kamar'];?><br>
              <label class="form-check-label" for="credit">Jumlah Orang: </label><?php echo $row['jml_orang'];?><br>
              <label class="form-check-label" for="credit">Total Bayar:</label> <?php echo $row['total_bayar'];?><br>
          <hr class="my-4">

          <button class="w-100 btn btn-primary btn-lg" type="submit"><a style="color: black;" href="bayar.php?kd_reservasi=<?=$row['kd_reservasi'];?>">Lanjutkan ke Pembayaran</a></button>
          
        </form>
      </div>
    </div>
  </main>

  
</div>


    <script src="../assets/js/bootstrap.bundle.min.js"></script>

      <script src="../assets/js/form-validation.js"></script>
  </body>
</html>
