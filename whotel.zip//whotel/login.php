<!DOCTYPE html>
<html>
<head>
    <title>W'HOTEL</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="assets/img/43.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/43.png">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
<!--

-->
</head>

<body>
    <!-- Start Top Nav -->
    <nav class="navbar navbar-expand-lg bg-dark navbar-light d-none d-lg-block" id="templatemo_nav_top">
        <div class="container text-light">
            <div class="w-100 d-flex justify-content-between">
                <div>
                    <i class="fa fa-envelope mx-2"></i>
                    <i class="fa fa-phone mx-2"></i>
                </div>
                <div>
                    <a class="text-light" href="https://fb.com/templatemo" target="_blank" rel="sponsored"><i class="fab fa-facebook-f fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://twitter.com/" target="_blank"><i class="fab fa-twitter fa-sm fa-fw me-2"></i></a>
                    <a class="text-light" href="https://www.linkedin.com/" target="_blank"><i class="fab fa-linkedin fa-sm fa-fw"></i></a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Close Top Nav -->


    <!-- Header -->
   
<style>
body {
background-image:
url("images/swimming-pool.jpg");
background-size: cover;
background-position: center;
background-repeat: no repeat;
}





input[type=email],select{
box-shadow: 5px 10px 20px rgba(0,0,0,0.7);
background-color: transparent;
width: 100%;
height: 50px;
padding: 12px 50px; 
margin: 10px 0px;
display: inline-block;  
border-radius: 0%; 
box-sizing: border-box;
border:1px solid white;
font-size:20px;
font-family: serif ;
cursor: center;
}

input[type=password]{
box-shadow: 5px 5px 5px rgba(0,0,0,0.5);
background-color: transparent;
width: 100%;
padding: 12px 50px; 
margin: 10px 0px;
display: inline-block;  
border-radius: 2%; 
box-sizing: border-box;
border:1px solid white;
font-size:20px;
font-family: serif ;
cursor: center;
}

input[type=submit] {
width: 100%;
height: 50px;
font-color: white;
background-color: white;
padding: 14px 20px; 
margin: 15px 0;
border:2px solid white; 
border-radius: 0px; 
cursor: center;
font-family: serif ;
}

input[type=submit] : hover {
font-color: white;
}

div{
border-radius: 10px; 
backgroud-color: #f2f2f2;
padding : 5px; 
}

.kotak {
box-shadow: 5px 10px 20px rgba(0,0,0,0.7);
position: center;
border: none;
width: 550px;
height: 350px;
margin: 40px auto 200px auto;
padding: 10px;
}

.inilogin {
position: center;
border: none;
width: 500px;
height: 300px;
margin: 40px auto 200px auto;
padding: 10px;
}

h1{
-webkit-text-stroke:;
font-family: serif ;
font-size: 100px;
color: white;
text-align: center;
margin: 300px auto 0 auto; 
}

h2 {
margin: 15px auto 0 auto;
font-family: serif;
font-size: 60px;
text-align: center;
}

h4 {
padding: 5px;
margin: 0px auto 0 auto;
font-family: serif;
font-size: 50px;
text-align: center;
}

h6 {
padding: 10px;
font-family: serif;
font-color:white;
}

input[type=submit]{
font-family: serif;
font-size: 20px;
}

h3 {
margin: 15px auto 0 auto;
font-family: serif;
font-size: 60px;
text-align: center;
}
</style>
</head>

<body>
    <?php
    if(isset($_GET ['pesan'])){
        if($_GET['pesan']== "gagal"){
            echo"login gagal! username dan password salah!";

        }else if ($_GET['pesan']=="logout"){
            echo "anda telah berhasil logout";
             }else if ($_GET['pesan']=="belum_login"){
                echo"anda harus login untuk mengakses halaman admin";
            }
    }
    ?>
</br>
<h2><b>LOGIN</b></h2>
<div class="kotak">
<div class="inilogin">
<form method="POST" action="aksi_login.php">
<label></label></br>
<input type="email" placeholder="Email" name="email"></br>
<label></label></br>
<input type="password" placeholder="Password" name="kata_sandi"></br>
<h4 align="center"><input type="submit" value="LOGIN"></h4>
<h5 align="center"><a href="pendaftaran.php"><font color ="white">DONT HAVE ACCOUTN?</a></h5></font>
</form>
</div>
</div>
</body>
</html>
