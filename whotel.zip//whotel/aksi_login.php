<?php
session_start();
include'koneksi.php';
$email=$_POST['email'];
$password=md5($_POST['kata_sandi']);
$data=mysqli_query($koneksi,"select*from tbl_tamu where email='$email'and kata_sandi='$password'");
$cek=mysqli_num_rows($data);
if($cek>0){
$_SESSION['email']=$email;
$_SESSION['status']='login';
	header("location:tampilan_tamu.php");
}else{
	header ("location:masuk.php?pesan=gagal");
	}	
?>