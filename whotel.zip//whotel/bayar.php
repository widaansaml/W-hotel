<!doctype html>
<html lang="en">
  <head>
 
   
    <style>
      
    </style>

  </head>
  <body class="bg-light">
     <!-- cek apakah sudah login -->
	<?php 
	session_start();
    
	if($_SESSION['status']!="login"){
		header("location:index.php?pesan=belum_login");
 
	}
?>
  <?php
  include 'koneksi.php';
 
$email = $_SESSION['email'];
$kd_reservasi = $_GET['kd_reservasi'];
$data = mysqli_query($koneksi,"select * from tbl_reservasi JOIN tbl_tamu ON tbl_reservasi.id_tamu=tbl_tamu.id_tamu
                     JOIN tbl_tipe_kamar ON tbl_reservasi.id_kamar=tbl_tipe_kamar.id_kamar where kd_reservasi='$kd_reservasi'");
	$row = mysqli_fetch_array($data);


    	// mengambil data tamu dengan kode paling besar
	$query = mysqli_query($koneksi, "SELECT max(kd_bayar) as kd_bayar FROM tbl_pembayaran");
	$data_bayar = mysqli_fetch_array($query);
	$kd_bayar = $data_bayar['kd_bayar'];
 
	$urutan = (int) substr($kd_bayar, 3, 3);
 
	// bilangan yang diambil ini ditambah 1 untuk menentukan nomor urut berikutnya
	$urutan++;
 
	// membentuk kode barang baru
	// perintah sprintf("%03s", $urutan); berguna untuk membuat string menjadi 3 karakter
	// misalnya perintah sprintf("%03s", 15); maka akan menghasilkan '015'
	// angka yang diambil tadi digabungkan dengan kode huruf yang kita inginkan, misalnya BRG 
	$huruf = "BYR";
	$kd_bayar = $huruf . sprintf("%03s", $urutan);
?>
<div class="container">
  <main>
  

    <h4 class="mb-3">Pembayaran</h4>
          <hr class="my-4">
          <form method="POST" action="aksibayar.php"></form>
          <table border="1px" width="48px" heigth="67px">
          <div class="row gy-3">
            <div class="col-md-12">
              <label for="cc-name" class="form-label">Kode Reservasi</label>
              <input type="text" class="form-control" id="cc-name" name="kd_reservasi" value="<?= $row['kd_reservasi'];?>" readonly>
              <input type="hidden" class="form-control"  name="tgl_bayar" value="<?php echo date("Y-m-d"); ?>
              <input type="hidden" class="form-control"  name="kd_bayar" value="<?php echo $kd_bayar;?>">
            </div><br>
            <div class="col-md-12">
              <label for="cc-name" class="form-label">Nama Pemesan</label>
              <input type="text" class="form-control" id="cc-name" name="nama_pengguna" value="<?= $row['nama_pengguna'];?>" readonly>
            </div><br>
            <div class="col-md-12">
              <label for="cc-number" class="form-label">Nama Akun Rekening </label>
              <input type="text" class="form-control" id="cc-number" name="nama_akun_rekening"  placeholder="" required>
            </div><br>

            <div class="col-md-12">
              <label for="cc-expiration" class="form-label">Nomor Rekening </label>
              <input type="text" class="form-control" id="cc-expiration" name="no_rek" placeholder="" required>
            </div><br>
            <div class="col-md-12">
              <label for="cc-cvv" class="form-label">Upload Bukti Transfer</label>
              <input type="file" class="form-control" id="cc-cvv" name="bukti_bayar" placeholder="" required>
            </div>
          </div>

          <hr class="my-4">

          <button class="w-100 btn btn-primary btn-lg" type="submit">Bayar</button>
        </form>
      </div>
    </div>
  </table>
  </main>

    
</div>

  </body>
</html>